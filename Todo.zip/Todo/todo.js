
function newElement() {
  var inputValue1= document.getElementById("task-detail").innerHTML;
  var inputValue2= document.getElementById("category").innerHTML;
  var inputValue3= document.getElementById("date").innerHTML;
}
button.addEventListener('click', function () {
  if (inputValue1=== ''||inputValue2=== ''||inputValue3=== '') {
    alert("You must write something!");
  } else {
    var todo=[] ,cart{};
    todo.li1 = inputValue1;
	todo.li2 = inputValue2;
	todo.li3 = inputValue3;
	todo.completed=false;
	cart.push(todo);
  


)};
console.log(inputvalue1);